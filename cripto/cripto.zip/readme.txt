python 3.5

Fisierul rsa2.py e scris non-pythonic, 
	fara list comprehensions and other python candy,
	pentru cei care nu sunt pasionati de python/sunt prea presati
	de timp sa mai invete asa ceva :P.

Recomand rsa.py daca stiti python sau daca vreti sa invatati niste
	chestii python specific, varianta asta are si replacing in ciphertext 
	pentru ' ' cu '_' si niste validari

O data ce aveti instalat python 3.5, recomand sa folositi virtualenv,
	(tutorial aici: http://timmyreilly.azurewebsites.net/python-pip-virtualenv-installation-on-windows/)
	dar daca nu vreti, trebuie doar sa rulati 'pip install appJar' pentru ca partea de GUI sa functioneze.
	Partea de 'pip install appJar' este necesara si daca folositi virtualenv.
	


