
Este doar algoritmul, fara I/O sau GUI.

E posibil sa nu fie perfect si nu sunt validari pe plaintext/cipher.

Pentru chestii specifice din Python si/sau GUI recomand sa va uitati in fisierul 'Lab RSA Python cu GUI' deoarece
	in fisierul rsa2.py, list comprehensions sunt schimbate in for-uri standard, mai usor de inteles pentru cei
	care nu au experienta in-depth cu Python, iar GUI-ul este total implementat pentru RSA.

